import { json, Link, useNavigate } from 'react-router-dom';
import './navbar.css'

const Navbar = () => {

    let navigate=useNavigate()
   let length=JSON.parse(localStorage.getItem('favourites'))
   
   let un=JSON.parse( localStorage.getItem('data')) 
   

   
    let handlesignout=()=>{
        localStorage.removeItem('data')
        navigate('/')
    }
    
    
    return ( 
        <div className="navbar">
            <nav>
               <Link to="/home"> <h1>Home</h1> </Link>
                {/* <div className="searchbar">
                    <input type="search" name="" id="search-input" placeholder="Search here" />
                    <button id='searchbtn'>Search</button>
                </div> */}
             <Link to="/favourites"><button id='favourites'>Favourites <p >{length.length} </p></button></Link> 
              <button>Username : <span id='uname'>{un.name.toUpperCase()}</span> </button>
              <button onClick={handlesignout}>Logout</button>
            </nav>
        </div>
     );
}
 
export default Navbar;
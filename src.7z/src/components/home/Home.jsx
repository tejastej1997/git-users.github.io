import "./home.css"


import { useEffect } from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../navbar/Navbar";


const Home = () => {
  

    let[data,setData]=useState(null)
    let[currentData,setCurrentData]=useState(5);

      useEffect(()=>{
        if(localStorage.getItem("favourites")==null)
        {
          localStorage.setItem("favourites" , "[]")
        }




        setTimeout(() => {
            fetch("https://api.github.com/users")
            .then((response)=>{
              return response.json()
            })
            .then((result)=>{
                // console.log(result.forEach((d)=>{console.log(d);}));
                let currentdata=result.slice(0,5);
                setData(result);
                setCurrentData(currentdata);
            })
            .catch((err)=>{
                alert(err.message)
            })
            
        }, 1000);
      },[])
 
  
      
      let handleloadmore=()=>{
        setCurrentData(data.slice(0,currentData.length+5))
        // setCurrentData(currentData+currentData)

      }
   

  
    return ( 
       <div className="home">
        <Navbar/>
        <h1>Details of git Users</h1>
        {data && <div className="details-division">
            {
                currentData.map((d)=>{
                    return(
                        
                        <div className="user-list" key={d.id}>
                            <Link to={`/userdetails/${d.id}`}>
                              <img src={d.avatar_url} alt="" width="200px" height="200px" />
                            <h3>User name: <br /> {d.login.toUpperCase()}</h3>
                            </Link>
                        </div>
                       
                )
                })
            }
            <button onClick={handleloadmore} id="load-more" >Load More</button>
        </div> }
       </div>

        
     );
}
 
export default Home;
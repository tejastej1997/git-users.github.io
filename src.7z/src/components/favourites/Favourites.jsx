import { Link } from 'react-router-dom';
import Navbar from '../navbar/Navbar';
import './favourites.css'
const Favourites = () => {
  
    let favouriteitem=JSON.parse(localStorage.getItem('favourites'))
    let identity=favouriteitem.findIndex((fi)=>{
        return fi.id
    })
    console.log(identity);
    let handleremove=()=>{
        // favouriteitem.splice(start,1)
    }


    return ( 
       <>
        <Navbar/>
      
        <div className="favourites">
           
            {
                favouriteitem.map((f)=>{
                   return(
                    
                    <div className="favourites-details">
                        <Link to={`/userdetails/${f.login}`}>
                    <img src={f.avatar_url} alt="" width="50px" height="50px" />
                    <h1>{Number(f.name) ? `Not Given` : `${f.name}`}</h1>
                    </Link>
                    <button onClick={handleremove}>Remove</button>
                    
                    
                    </div>
                   )
                })
            }
        </div>

        </>
     );
}
 
export default Favourites;
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const Individualfollowers = () => {
  let{id}=useParams()

    let [data,setData]=useState()
    useEffect(()=>{
        setTimeout(() => {
            fetch('https://api.github.com/users/'+id)
            .then(()=>{})
        }, 1000);
    },[])


    return ( 
   
      

        <>
        <h1>Page is rendered</h1>
        </>
     );
}
 
export default Individualfollowers;
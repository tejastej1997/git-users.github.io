
import { useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './signin.css'

const Signin = () => {
    
    let mail=useRef()
    let password=useRef()
    let navigate=useNavigate()

    let handlesignin=(e)=>{
      e.preventDefault()

      fetch('http://localhost:4000/database')
      .then((response)=>{
          return response.json()
      })
      .then((result)=>{
        
       let loginmail=result.find((l)=>{
            return mail.current.value==l.email
       })
      
         if(loginmail==null)
         {
            alert("Entered email does not exist please check")
         }
         else if(loginmail.password!=password.current.value)
         {
            alert("Password does not match email entered")
         }
         else
         {
            if(localStorage.getItem('data')==null)
            {
                localStorage.setItem('data','[]')
            }
           
            localStorage.setItem('data',JSON.stringify(loginmail) )

            alert("login successful")
            navigate('/home')
         }
      })

    

    }
 

    


    return ( 
      <div className="sign-in">
        <form action="" onSubmit={handlesignin} >
            <input type="email" placeholder="Enter email here" ref={mail} required />
            <input type="password" name="" id=""  placeholder="Enter password" ref={password} required />
            <div className="btn">
            <input type="submit" value="Sign-in" />
           
            </div>
            <div className="signup-content">
            <p>Not have an account?</p>
            <Link to="/">
              Sign up
             
           </Link> 
           </div>

        </form>
      </div>
     );
}
 
export default Signin;
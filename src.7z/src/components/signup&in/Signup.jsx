import { useRef } from 'react';
import {  Link, useNavigate } from 'react-router-dom';
import './signup.css'


const Signup = () => {
    let username=useRef()
    let email=useRef()
    let password=useRef()
    let cpassword=useRef()
    let navigate=useNavigate()
    
    let handlesignup=(e)=>{
      e.preventDefault()

      let newdata={
        name:username.current.value,
        email:email.current.value,
        password:password.current.value,
        cpassword:cpassword.current.value
      }
       
      fetch(' http://localhost:4000/database')
      .then((response)=>{
        return response.json()
      })
      .then((result)=>{
        let finddata=result.find((f)=>{
           return f.name==username.current.value
        })
        let findemail=result.find((m)=>{
           return m.email==email.current.value
        })
           
         if(finddata!=null)
         {
            alert('Username already exists')
         }
         else if(findemail!=null)
         {
            alert('email already registered')
         }
         else if(password.current.value==cpassword.current.value)
         {
           fetch(' http://localhost:4000/database',{
               method:"POST",
               headers:{"Content-Type" : "application/json"},
               body:JSON.stringify(newdata)
             })
             .then(()=>{
              
                if(localStorage.getItem('data')==null)
                {
                    localStorage.setItem("data",'[]')
                }

                localStorage.setItem('data',JSON.stringify(newdata))

               alert("Credentials saved successfully")
                navigate("/signin")
             })
         }
         else
         {
           alert('password does not match')
           
         }
      })


    }


    return ( 
       <div className="sign-up">
        <form action="" onSubmit={handlesignup}>
    <div className="form-content">
        <label htmlFor="">Username <span>*</span> </label>
        <input type="text" placeholder="Enter Username" ref={username} required />

        <label htmlFor="">Email <span>*</span> </label>
        <input type="email" placeholder="Enter Email" ref={email} required />

        <label htmlFor="">Password  <span>*</span> </label>
        <input type="password" placeholder="Enter password" ref={password} required />

        <label htmlFor="">Confirm password  <span>*</span> </label>
        <input type="text" placeholder="Confirm Password" ref={cpassword} required />
        

        <input type="Submit" value="Sign-up" />
      

        </div>
        <div className="signin-content">
          <p>Already have an account ? </p>
        <Link to="/signin"> Sign-in</Link> 
        </div>

 


        </form>
       </div>
     );
}
 
export default Signup;

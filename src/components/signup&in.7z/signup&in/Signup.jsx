import { useState } from 'react';
import { auth } from '../../firebase-config';
import { Link, useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword } from "firebase/auth";


import './signup.css'










const Signup = () => {

  let navigate = useNavigate()

 let gpassword=document.getElementById('gpassword')
 let cpassword=document.getElementById('cpassword')



  
  let[email,setEmail]=useState("")
  let[password,setPassword]=useState("")




  let handlesignup = (e) => {
    e.preventDefault()


    if(gpassword.value==cpassword.value)
    {

      createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Signed in 
        const user = userCredential.user;
        console.log(user.email);
        alert("Sign up completed as :"+ user.email)
        navigate('/home')
        // ...
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        alert(errorMessage)
        // ..
      });
    }
    else
    {
      alert('please check the password')
      cpassword.style.border="0.5px solid red"
    }
    
 



  }


  return (
    <div className="sign-up">
      <form action="" onSubmit={handlesignup}>
        <div className="form-content">


          <label htmlFor="">Email <span>*</span> </label>
          <input type="email" placeholder="Enter Email" required onChange={(e)=>{setEmail(e.target.value)}}/>

          <label htmlFor="">Password  <span>*</span> </label>
          <input type="password" id='gpassword' placeholder="Enter password" required onChange={(e)=>{setPassword(e.target.value)}} />

          <label htmlFor="">Confirm password  <span>*</span> </label>
          <input type="text" id='cpassword' placeholder="Confirm Password" required />


          <input type="Submit" value="Sign-up" />


        </div>
        <div className="signin-content">
          <p>Already have an account ? </p>
          <Link to="/signin"> Sign-in</Link>
        </div>
        <div className="signin-content">

          <p>Sign in with <Link to="/home"> <span id='google'> Google</span> </Link></p>

        </div>




      </form>
    </div>
  );
}

export default Signup;

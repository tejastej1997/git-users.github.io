import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../../firebase-config";


import { Link, useNavigate } from 'react-router-dom';
import './signin.css'
import { useState } from "react";

const Signin = () => {


   let[email,setEmail]=useState("")
   let[password,setPassword]=useState("")
   




   let navigate = useNavigate()

   let handlesignin = (e) => {
      e.preventDefault()

      signInWithEmailAndPassword(auth, email, password)
         .then((userCredential) => {
            // Signed in 
            const user = userCredential.user;
            console.log(user.email);
            alert("Signin successful as :" + user.email)
            navigate('/home')

            // ...
         })
         .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            alert(errorMessage)
         });


   }





   return (
      <div className="sign-in">
         <form action="" onSubmit={handlesignin} >
            <input type="email" placeholder="Enter email here" onChange={(e)=>{setEmail(e.target.value)}} required />
            <input type="password" name="" id="" placeholder="Enter password"  required  onChange={(e)=>{setPassword(e.target.value)}} />
            <div className="btn">
               <input type="submit" value="Sign-in" />

            </div>
            <div className="signup-content">
               <p>Not have an account?</p>
               <Link to="/">
                  Sign up
               </Link>

            </div>

         </form>
      </div>
   );
}


export default Signin;